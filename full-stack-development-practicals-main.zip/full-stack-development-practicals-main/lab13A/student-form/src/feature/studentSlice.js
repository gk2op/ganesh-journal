import { createSlice } from "@reduxjs/toolkit";

const studentSlice = createSlice({
  name: "students",

  initialState: {
    list: [],
  },

  reducers: {
    addStudent: (state, action) => {
      state.list.push(action.payload);
    },

    deleteStudent: (state, action) => {
      state.list = state.list.filter(
        (student) => student.id !== action.payload
      );
    },
  },
});

export const { addStudent, deleteStudent } = studentSlice.actions;
export default studentSlice.reducer;